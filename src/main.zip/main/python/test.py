from sqlitedb import DB
from lib.constants import *
from customWidgets import *
import time
from collections import OrderedDict

db= DB(str(confPath() /Path(CAMINHO['escola'])), TABLE_NAME['escola'], ATRIBUTOS['escola'])
start_time = time.time()
#todasSeries=sorted(list(set(sum([escola["series"].split(",") for escola in db.todosOsDados()], []))))
todasasSeries=list(OrderedDict.fromkeys(sum([escola["series"].split(SEPARADOR_SERIES) for escola in db.todosOsDados()],[])))
print(todasasSeries)
print("--- %s seconds ---" % (time.time() - start_time))
